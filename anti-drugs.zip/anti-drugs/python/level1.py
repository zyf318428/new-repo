#level 1 fusion


face_path = sys.argv[1]
cropImageName = face_path.split("/")[-1]
cropImageName = './afterdrugs/' + cropImageName

im1 = Image.open(cropImageName)
im2 = Image.open('./python/wenli17.jpg') #name of picture wenli
#im2 = Image.open('wenli1.jpg') #name of picture wenli
contrast = ImageEnhance.Contrast(im2)
im2 = contrast.enhance(2.0)
out = Image.blend(im1, im2, 0.25)
out.save(cropImageName)
out.show()